package de.trakuna.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private val Forest = Color(0xFF164B38)
private val Pale = Color(0xFFE8F1EB)
private val Page = Color(0xFFF4F7F4)

private data class ParcelItem(
    val number: String,
    val customer: String,
    val type: String,
    val status: String,
    val updated: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Forest, background = Page)) { TrakunaApp() } }
    }
}

private fun loadParcels(context: Context): List<ParcelItem> = runCatching {
    val raw = context.getSharedPreferences("trakuna", Context.MODE_PRIVATE).getString("parcels", "[]") ?: "[]"
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i)
        ParcelItem(o.getString("number"), o.optString("customer"), o.getString("type"), o.getString("status"), o.optLong("updated"))
    }
}.getOrDefault(emptyList())

private fun saveParcels(context: Context, parcels: List<ParcelItem>) {
    val array = JSONArray()
    parcels.forEach { p -> array.put(JSONObject().put("number", p.number).put("customer", p.customer).put("type", p.type).put("status", p.status).put("updated", p.updated)) }
    context.getSharedPreferences("trakuna", Context.MODE_PRIVATE).edit().putString("parcels", array.toString()).apply()
}

@Composable
private fun TrakunaApp() {
    val context = LocalContext.current
    var flow by remember { mutableStateOf("Annahme") }
    var tracking by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Bereit. Wähle einen Ablauf oder scanne einen Barcode.") }
    var scannerOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val parcels = remember { mutableStateListOf<ParcelItem>().apply { addAll(loadParcels(context)) } }
    LaunchedEffect(parcels.toList()) { saveParcels(context, parcels.toList()) }

    if (scannerOpen) {
        ScannerScreen(
            onCode = { code -> tracking = code; scannerOpen = false; notice = "Barcode erkannt: $code" },
            onClose = { scannerOpen = false }
        )
        return
    }

    Column(Modifier.fillMaxSize().background(Page)) {
        Column(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 17.dp)) {
            Text("TRAKUNA", color = Forest, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            Text("ALLE PAKETDIENSTE. EIN SMARTPHONE.", color = Forest, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(19.dp)) {
                        Text("SCAN-ZENTRALE", color = Color.White.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Was möchtest du erledigen?", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Pakete annehmen, ausgeben, retournieren und versenden.", color = Color.White.copy(alpha = .88f), fontSize = 12.sp)
                    }
                }
            }
            item { Text("PAKETSHOP-FUNKTIONEN", color = Forest, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            item {
                val flows = listOf("Annahme" to "Paket entgegennehmen", "Abholung" to "An Kunden ausgeben", "Retoure" to "Rücksendung erfassen", "Versand" to "An Paketdienst übergeben")
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    flows.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            pair.forEach { item ->
                                val active = flow == item.first
                                Card(onClick = { flow = item.first; notice = "${item.first} ausgewählt." }, modifier = Modifier.weight(1f).height(88.dp), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = if (active) Pale else Color.White), border = if (active) BorderStroke(1.5.dp, Forest) else null) {
                                    Column(Modifier.fillMaxSize().padding(13.dp), verticalArrangement = Arrangement.Center) {
                                        Text(item.first, color = Forest, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                        Text(item.second, color = Color.DarkGray, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(flow.uppercase(), color = Forest, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        OutlinedTextField(value = tracking, onValueChange = { tracking = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Sendungsnummer / Barcode") }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters), leadingIcon = { Icon(Icons.Default.QrCodeScanner, null) })
                        OutlinedButton(onClick = { scannerOpen = true }, modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("BARCODE MIT KAMERA SCANNEN", fontWeight = FontWeight.Bold)
                        }
                        if (flow == "Annahme" || flow == "Retoure") {
                            OutlinedTextField(value = customer, onValueChange = { customer = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Kundenname (optional)") }, singleLine = true)
                        }
                        Button(onClick = {
                            val number = tracking.trim()
                            if (number.isBlank()) { notice = "Bitte Sendungsnummer eingeben oder scannen."; return@Button }
                            when (flow) {
                                "Annahme" -> { if (parcels.any { it.number == number && it.status == "Eingelagert" }) notice = "Diese Sendung ist bereits eingelagert." else { parcels.add(0, ParcelItem(number, customer.trim(), "Annahme", "Eingelagert")); notice = "Paket lokal erfasst und eingelagert." } }
                                "Retoure" -> { parcels.add(0, ParcelItem(number, customer.trim(), "Retoure", "Retoure bereit zur Übergabe")); notice = "Retoure lokal erfasst." }
                                "Abholung" -> { val i = parcels.indexOfFirst { it.number == number && it.status == "Eingelagert" }; if (i >= 0) { parcels[i] = parcels[i].copy(status = "Abgeholt", updated = System.currentTimeMillis()); notice = "Paket als abgeholt markiert." } else notice = "Kein eingelagerter Treffer. Nummer prüfen." }
                                "Versand" -> { val i = parcels.indexOfFirst { it.number == number && (it.status.contains("Retoure") || it.status == "Eingelagert") }; if (i >= 0) { parcels[i] = parcels[i].copy(status = "An Paketdienst übergeben", updated = System.currentTimeMillis()); notice = "Übergabe lokal dokumentiert." } else notice = "Kein passender offener Vorgang gefunden." }
                            }
                            if (notice.contains("erfasst") || notice.contains("markiert") || notice.contains("dokumentiert")) { tracking = ""; customer = "" }
                        }, modifier = Modifier.fillMaxWidth().height(51.dp), shape = RoundedCornerShape(13.dp)) { Text("VORGANG AUSFÜHREN", fontWeight = FontWeight.Bold) }
                        Text(notice, color = Forest, fontSize = 12.sp)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("PAKETÜBERSICHT (${parcels.size})", color = Forest, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = Forest)
                }
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Pakete suchen") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
            }
            val visible = parcels.filter { search.isBlank() || it.number.contains(search, true) || it.customer.contains(search, true) }
            if (visible.isEmpty()) item { Text(if (parcels.isEmpty()) "Noch keine Pakete erfasst." else "Keine passenden Pakete gefunden.", color = Color.Gray, fontSize = 13.sp) }
            items(visible, key = { "${it.number}-${it.type}-${it.updated}" }) { parcel ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(parcel.number, color = Forest, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${parcel.type} • ${parcel.status}", color = Color.DarkGray, fontSize = 11.sp)
                            if (parcel.customer.isNotBlank()) Text("Kunde: ${parcel.customer}", color = Color.Gray, fontSize = 11.sp)
                        }
                        if (parcel.status == "Eingelagert") AssistChip(onClick = { flow = "Abholung"; tracking = parcel.number; notice = "Sendung zur Abholung ausgewählt." }, label = { Text("Ausgeben") })
                    }
                }
            }
            item { Text("TRAKUNA 2.1 • LOKALE TESTVERSION", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
        }
    }
}

@Composable
private fun ScannerScreen(onCode: (String) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().background(Forest).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = Color.White) }
            Column {
                Text("BARCODE-SCANNER", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Code in den Rahmen halten", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
            }
        }
        if (granted) {
            CameraPreview(onCode = onCode, lifecycleOwner = lifecycleOwner, modifier = Modifier.weight(1f).fillMaxWidth())
            Text("Unterstützt gängige Paket-Barcodes und QR-Codes.", color = Color.White, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(18.dp))
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp)); Text("Kamerazugriff wird zum Scannen benötigt.", color = Color.White)
                Spacer(Modifier.height(14.dp)); Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("KAMERA FREIGEBEN") }
                TextButton(onClick = onClose) { Text("Abbrechen", color = Color.White) }
            }
        }
    }
}

@Composable
private fun CameraPreview(onCode: (String) -> Unit, lifecycleOwner: androidx.lifecycle.LifecycleOwner, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    AndroidView(modifier = modifier, factory = { ctx ->
        val previewView = PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
        val executor = Executors.newSingleThreadExecutor()
        val scanner = BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build())
        cameraProviderFuture.addListener({
            runCatching {
                val provider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                var lastValue = ""
                var lastAt = 0L
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null) { proxy.close() } else {
                        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        scanner.process(image)
                            .addOnSuccessListener { barcodes ->
                                val value = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                if (!value.isNullOrBlank() && (value != lastValue || System.currentTimeMillis() - lastAt > 1800)) {
                                    lastValue = value; lastAt = System.currentTimeMillis(); previewView.post { onCode(value) }
                                }
                            }
                            .addOnCompleteListener { proxy.close() }
                    }
                }
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            }
        }, ContextCompat.getMainExecutor(ctx))
        previewView
    })
}

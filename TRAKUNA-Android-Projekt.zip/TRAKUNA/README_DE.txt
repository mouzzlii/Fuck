TRAKUNA – Android-Testprojekt
=============================

Enthaltene Funktionen:
- Kamera-Barcode-/QR-Scanner (CameraX + ML Kit)
- Manuelle Eingabe von Sendungsnummern und Barcodes
- Paketannahme und Einlagerung
- Kundenausgabe
- Retourenannahme
- Übergabe an Versanddienstleister
- Lokale Speicherung und Suche
- Smartphone-Oberfläche in Waldgrün

APK erstellen:
Das Projekt enthält einen GitHub-Actions-Workflow unter
.github/workflows/android-build.yml. Nach dem Hochladen dieses Projektordners
in ein GitHub-Repository und Push startet der Workflow automatisch.
Die fertige Debug-APK liegt danach im GitHub-Actions-Lauf unter
„Artifacts“ als „TRAKUNA-debug-APK“ zum Herunterladen.

Alternativ lässt sich das Projekt mit Android Studio öffnen und über
Build > Build Bundle(s) / APK(s) > Build APK(s) erstellen.

Wichtige Grenzen dieser Testversion:
- Paketdaten werden lokal auf diesem Gerät gespeichert.
- Es sind keine echten Schnittstellen zu Post, DHL, DPD, GLS, UPS oder
  anderen Versanddienstleistern angebunden.
- Es gibt keine Cloud-Synchronisierung, Benutzerkonten oder Live-Tracking.
- Die APK wurde in dieser Umgebung nicht kompiliert oder auf einem Gerät
  ausgeführt, weil hier Android SDK und Gradle nicht installiert sind.

Vor einem produktiven Einsatz sind Build, Kameraberechtigung, Scans unter
verschiedenen Lichtbedingungen und alle Paketabläufe auf echten Geräten zu testen.
